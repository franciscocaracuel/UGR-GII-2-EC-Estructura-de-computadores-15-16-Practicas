// size.cc

#include <array>        // array
#include <chrono>       // high_resolution_clock
#include <iomanip>      // setw
#include <iostream>     // cout

using namespace std::chrono;

const unsigned LINE = 64;                // line size
const unsigned MINSIZE = 1<<10;           // maximun cache size to test
const unsigned MAXSIZE = 1<<28;           // maximun cache size to test
const unsigned GAP = 12;                 // gap for cout columns
const unsigned REP = 10;                 // number of repetitions of every test
const unsigned STEPS = 1<<25; // 32M steps

std::array<char, MAXSIZE> bytes;         // 32MB

int main()
{
	std::cout << "#" 
	          << std::setw(GAP - 1) << "size (B)"
	          << std::setw(GAP    ) << "time (ms)"
	          << std::endl;

	bytes.fill(0);

	for (unsigned long long size = MINSIZE; size <= MAXSIZE; size <<= 1)
	{
		std::array<duration<float, std::milli>, REP> score;

		for (auto &s: score)
		{
			auto start = high_resolution_clock::now();

			for (unsigned long long i = 0; i < STEPS; i++)
				//bytes[i%size] ^= 1;
				bytes[(i<<6)&(size-1)] ^= 1;

			auto stop = high_resolution_clock::now();

			s = stop - start;
		}

		std::cout << std::setw(GAP) << size
		          << std::setw(GAP) << std::fixed << std::setprecision(2)
		          << std::setw(GAP) << std::min(score.begin(), score.end())->count()
		          << std::endl;
	}

	return bytes.front() + bytes.back();
}
